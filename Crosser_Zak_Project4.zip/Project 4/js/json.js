var json = {
  "transaction1": {
    "date": ["Date", "2012-08-21"],
    "transType": ["Type", "Deposit" ],
    "catagory": ["Catagory", "Credit_Card"],
    "amount": ["Amount", "500.00"],
    "notes": ["Notes", "New Card"],
    "slider": ["Slider", "50"],
    "checkBox": ["Is it a reccuring transation", "No"]
  },

  "transaction2": {
    "date": ["Date", "2012-08-22"],
    "transType": ["Type", "Adjustment" ],
    "catagory": ["Catagory:", "Food"],
    "amount": ["Amount", "6.98"],
    "notes": ["Notes", "Wendy's"],
    "slider": ["Slider", "50"],
    "checkBox": ["Is it a reccuring transation", "No"]
  },

  "transaction3": {
    "date": ["Date", "2012-08-23"],
    "transType": ["Type", "Withdraw" ],
    "catagory": ["Catagory", "Entertainment"],
    "amount": ["Amount", "58.04"],
    "notes": ["Notes", "Movies"],
    "slider": ["Slider", "50"],
    "checkBox": ["Is it a reccuring transation", "No"]
  },

  "transaction4": {
    "date": ["Date", "2012-08-24"],
    "transType": ["Type", "Transfer" ],
    "catagory": ["Catagory", "ATM_Withdraw"],
    "amount": ["Amount", "230.00"],
    "notes": ["Notes", "Transfer to Checking"],
    "slider": ["Slider", "50"],
    "checkBox": ["Is it a reccuring transation", "No"]
  }
}